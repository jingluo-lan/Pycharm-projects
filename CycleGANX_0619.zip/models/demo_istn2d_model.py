import torch
import itertools
from util.image_pool import ImagePool
from .base_model import BaseModel
from . import networks
import sys
sys.path.append('/home/ziyuan/UDA/Meta_istn_pre')
from istn.models.stn import BSplineSTN2D

class DEMOISTN2DModel(BaseModel):
    @staticmethod
    def modify_commandline_options(parser, is_train=True):
        """Add new dataset-specific options, and rewrite default values for existing options.

        Parameters:
            parser          -- original option parser
            is_train (bool) -- whether training phase or test phase. You can use this flag to add training-specific or test-specific options.

        Returns:
            the modified parser.

        For CycleGAN, in addition to GAN losses, we introduce lambda_A, lambda_B, and lambda_identity for the following losses.
        A (source domain), B (target domain).
        Generators: G_A: A -> B; G_B: B -> A.
        Discriminators: D_A: G_A(A) vs. B; D_B: G_B(B) vs. A.
        Forward cycle loss:  lambda_A * ||G_B(G_A(A)) - A|| (Eqn. (2) in the paper)
        Backward cycle loss: lambda_B * ||G_A(G_B(B)) - B|| (Eqn. (2) in the paper)
        Identity loss (optional): lambda_identity * (||G_A(B) - B|| * lambda_B + ||G_B(A) - A|| * lambda_A) (Sec 5.2 "Photo generation from paintings" in the paper)
        Dropout is not used in the original CycleGAN paper.
        """
        parser.set_defaults(no_dropout=True)  # default CycleGAN did not use dropout
        if is_train:
            parser.add_argument('--lambda_A', type=float, default=10.0, help='weight for cycle loss (A -> B -> A)')
            parser.add_argument('--lambda_B', type=float, default=10.0, help='weight for cycle loss (B -> A -> B)')
            parser.add_argument('--lambda_identity', type=float, default=0.5, help='use identity mapping. Setting lambda_identity other than 0 has an effect of scaling the weight of the identity mapping loss. For example, if the weight of the identity loss should be 10 times smaller than the weight of the reconstruction loss, please set lambda_identity = 0.1')

        return parser

    def __init__(self, opt):
        """Initialize the CycleGAN class.

        Parameters:
            opt (Option class)-- stores all the experiment flags; needs to be a subclass of BaseOptions
        """
        BaseModel.__init__(self, opt)
        # specify the training losses you want to print out. The training/test scripts will call <BaseModel.get_current_losses>
        self.loss_names = ['D_A', 'G_A','S_A', 'cycle_A', 'idt_A', 'D_B', 'G_B','S_B','cycle_B', 'idt_B']
        # specify the images you want to save/display. The training/test scripts will call <BaseModel.get_current_visuals>
        visual_names_A = ['A', 'A2B', 'A2BS', 'A2B2A', 'A2B2AS']
        visual_names_B = ['B', 'B2A', 'B2AS', 'B2A2B', 'B2A2BS']
        if self.isTrain and self.opt.lambda_identity > 0.0:  # if identity loss is used, we also visualize idt_B=G_A(B) ad idt_A=G_A(B)
            visual_names_A.append('A2A')
            visual_names_B.append('B2B')

        self.visual_names = visual_names_A + visual_names_B  # combine visualizations for A and B
        # specify the models you want to save to the disk. The training/test scripts will call <BaseModel.save_networks> and <BaseModel.load_networks>.
        if self.isTrain:
            self.model_names = ['G_A', 'G_B', 'D_A', 'D_B', 'S_A', 'S_B']
        else:  # during test time, only load Gs
                self.model_names = ['G_A', 'G_B']

        # define networks (both Generators and discriminators)
        # The naming is different from those used in the paper.
        # Code (vs. paper): G_A (G), G_B (F), D_A (D_Y), D_B (D_X)
        self.netG_A = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf, opt.netG, opt.norm,
                                        not opt.no_dropout, opt.init_type, opt.init_gain, self.gpu_ids)
        self.netG_B = networks.define_G(opt.output_nc, opt.input_nc, opt.ngf, opt.netG, opt.norm,
                                        not opt.no_dropout, opt.init_type, opt.init_gain, self.gpu_ids)
        self.netS_A = BSplineSTN2D([256,256],2,self.device,max_displacement=0.2)
        self.netS_B = BSplineSTN2D([256,256],2,self.device,max_displacement=0.2)

        if self.isTrain:  # define discriminators
            self.netD_A = networks.define_D(opt.output_nc, opt.ndf, opt.netD,
                                            opt.n_layers_D, opt.norm, opt.init_type, opt.init_gain, self.gpu_ids)
            self.netD_B = networks.define_D(opt.input_nc, opt.ndf, opt.netD,
                                            opt.n_layers_D, opt.norm, opt.init_type, opt.init_gain, self.gpu_ids)

        if self.isTrain:
            if opt.lambda_identity > 0.0:  # only works when input and output images have the same number of channels
                assert(opt.input_nc == opt.output_nc)
            self.A2BS_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            self.B2AS_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            # self.A2B_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            # self.B2A_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            # self.A2B2A_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            # self.B2A2A_pool = ImagePool(opt.pool_size)  # create image buffer to store previously generated images
            # define loss functions
            self.criterionGAN = networks.GANLoss(opt.gan_mode).to(self.device)  # define GAN loss.
            self.criterionCycle = torch.nn.L1Loss()
            self.criterionIdt = torch.nn.L1Loss()
            # initialize optimizers; schedulers will be automatically created by function <BaseModel.setup>.
            # import pdb; pdb.set_trace()
            istn_A2B_parameters = list(self.netG_A.parameters())+list(self.netS_A.parameters())
            istn_B2A_parameters = list(self.netG_B.parameters())+list(self.netS_B.parameters())
            self.optimizer_G = torch.optim.Adam(istn_A2B_parameters+istn_B2A_parameters, lr=opt.lr, betas=(opt.beta1, 0.999))
            self.optimizer_D = torch.optim.Adam(itertools.chain(self.netD_A.parameters(), self.netD_B.parameters()), lr=opt.lr, betas=(opt.beta1, 0.999))
            self.optimizers.append(self.optimizer_G)
            self.optimizers.append(self.optimizer_D)

    def set_input(self, input):
        """Unpack input data from the dataloader and perform necessary pre-processing steps.

        Parameters:
            input (dict): include the data itself and its metadata information.

        The option 'direction' can be used to swap domain A and domain B.
        """
        AtoB = self.opt.direction == 'AtoB'
        self.A = input['A' if AtoB else 'B'].to(self.device)
        self.B = input['B' if AtoB else 'A'].to(self.device)
        # self.image_paths = input['A_paths' if AtoB else 'B_paths']
        self.image_paths = input['A_paths']
    
    def forward(self):
        self.A2B = self.netG_A(self.A)  # G_A(A)
        self.netS_A(torch.cat((self.A2B, self.B),dim=1))
        self.A2BS = self.netS_A.warp_image(self.A2B)

        self.A2B2A =  self.netG_B(self.A2BS)
        self.netS_B(torch.cat((self.A2B2A, self.A),dim=1))   # G_B(G_A(A))
        self.A2B2AS = self.netS_A.warp_image(self.A2B2A)
        
        self.B2A = self.netG_B(self.B)  # G_B(B)
        self.netS_B(torch.cat((self.B2A, self.A),dim=1))
        self.B2AS = self.netS_B.warp_image(self.B2A)

        self.B2A2B = self.netG_A(self.B2AS)   # G_A(G_B(B))
        self.netS_A(torch.cat((self.B2A2B, self.B),dim=1))
        self.B2A2BS = self.netS_A.warp_image(self.B2A2B)


    def optimize_parameters(self):
        """Calculate losses, gradients, and update network weights; called in every training iteration"""
        # forward
        # A2B
        self.A2B = self.netG_A(self.A)  # G_A(A)
        self.netS_A(torch.cat((self.A2B, self.B),dim=1))
        self.A2BS = self.netS_A.warp_image(self.A2B)
        # A2B2A
        self.A2B2A =  self.netG_B(self.A2BS)
        self.netS_B(torch.cat((self.A2B2A, self.A),dim=1))   # G_B(G_A(A))
        self.A2B2AS = self.netS_B.warp_image(self.A2B2A)
        # B2A
        self.B2A = self.netG_B(self.B)  # G_B(B)
        self.netS_B(torch.cat((self.B2A, self.A),dim=1))
        self.B2AS = self.netS_B.warp_image(self.B2A)
        #B2A2B
        self.B2A2B = self.netG_A(self.B2AS)   # G_A(G_B(B))
        self.netS_A(torch.cat((self.B2A2B, self.B),dim=1))
        self.B2A2BS = self.netS_A.warp_image(self.B2A2B)
        # A2A
        self.A2A = self.netG_B(self.A)  # G_A(A)
        self.netS_B(torch.cat((self.A2A, self.A),dim=1))
        self.A2AS = self.netS_B.warp_image(self.A2A)
        # B2B
        self.B2B = self.netG_A(self.B)  # G_A(A)
        self.netS_A(torch.cat((self.B2B, self.B),dim=1))
        self.B2BS = self.netS_A.warp_image(self.B2B)

    
     # compute fake images and reconstruction images.
        # G_A and G_B
        self.set_requires_grad([self.netD_A, self.netD_B], False)  # Ds require no gradients when optimizing Gs
        self.optimizer_G.zero_grad()  # set G_A and G_B's gradients to zero
    # ISTN loss
        lambda_idt = self.opt.lambda_identity
        lambda_A = self.opt.lambda_A
        lambda_B = self.opt.lambda_B
        
        o_DA_A2B = self.netD_A(self.A2B)
        self.loss_G_A = torch.nn.functional.mse_loss(o_DA_A2B, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DA_A2B.shape).to(self.device))
        
        o_DA_A2BS = self.netD_A(self.A2BS)
        self.loss_S_A = torch.nn.functional.mse_loss(o_DA_A2BS, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DA_A2B.shape).to(self.device))

        
        o_DB_B2A = self.netD_B(self.B2A)
        self.loss_G_B = torch.nn.functional.mse_loss(o_DB_B2A, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DB_B2A.shape).to(self.device))
        
        o_DB_B2AS = self.netD_B(self.B2AS)
        self.loss_S_B = torch.nn.functional.mse_loss(o_DB_B2AS, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DB_B2A.shape).to(self.device))
        


        self.loss_idt_A = self.criterionIdt(self.A2AS, self.A) * lambda_A * lambda_idt
        self.loss_idt_B = self.criterionIdt(self.B2BS, self.B) * lambda_B * lambda_idt

        self.loss_cycle_A = self.criterionCycle(self.A2B2AS, self.A) * lambda_A
        self.loss_cycle_B = self.criterionCycle(self.B2A2BS, self.B) * lambda_B

        self.loss_G = self.loss_G_A + self.loss_G_B +self.loss_S_A+self.loss_S_B+ self.loss_cycle_A + self.loss_cycle_B + self.loss_idt_A + self.loss_idt_B
        self.loss_G.backward()
        self.optimizer_G.step() 

    # discriminator loss
        self.optimizer_D.zero_grad()   # set D_A and D_B's gradients to zero
        self.set_requires_grad(self.netD_A, True)
        A2BS = self.A2BS_pool.query(self.A2BS)
        o_DA_B = self.netD_A(self.B)
        loss_DA_real = torch.nn.functional.mse_loss(o_DA_B, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DA_B.shape).to(self.device))
        o_DA_A2B_D = self.netD_A(A2BS.detach())
        loss_DA_fake = torch.nn.functional.mse_loss(o_DA_A2B_D, \
            torch.distributions.Uniform(0.00, 0.03).sample(o_DA_A2B_D.shape).to(self.device))
        
        self.set_requires_grad(self.netD_B, True)
        B2AS = self.B2AS_pool.query(self.B2AS)
        o_DB_A = self.netD_B(self.A)
        loss_DB_real = torch.nn.functional.mse_loss(o_DB_A, \
            torch.distributions.Uniform(0.97, 1.00).sample(o_DB_A.shape).to(self.device))
        o_DB_B2A_D = self.netD_B(B2AS.detach())
        loss_DB_fake = torch.nn.functional.mse_loss(o_DB_B2A_D, \
            torch.distributions.Uniform(0.00, 0.03).sample(o_DB_B2A_D.shape).to(self.device))
        
        self.loss_D_A = (loss_DA_real + loss_DA_fake) * 0.5
        self.loss_D_A.backward()
        self.loss_D_B = (loss_DB_real + loss_DB_fake) * 0.5
        self.loss_D_B.backward()
        self.optimizer_D.step()  # update D_A and D_B's weights

