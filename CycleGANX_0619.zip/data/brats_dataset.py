import re
import glob
import torch.utils.data as data
import numpy as np
import torch
import imgaug.augmenters as iaa
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
import pandas as pd
import sys
from data.base_dataset import BaseDataset
from torchvision import transforms
import random

totensor = transforms.ToTensor()
class BRATSDataset(BaseDataset):
    @staticmethod
    def modify_commandline_options(parser, isTrain):
        parser.add_argument('--source_list', type=str, default='split_csv/source_all.csv', help='source list')
        parser.add_argument('--target_list', type=str, default='split_csv/target.csv', help='target list')
        parser.set_defaults(max_dataset_size=10, new_dataset_option=2.0)  # specify dataset-specific default values
        return parser
    def __init__(self, opt):
        
        BaseDataset.__init__(self, opt)
        # self.data = ['mr', 'ct']
        self.source_list = opt.source_list
        self.target_list = opt.target_list
        # print('Now reading: '+datalist)
        # self.data_name = 'chaos'
        # self.stat_dict = eval('stat_dic_'+self.data_name)
        # self.vol_stat = eval('vol_stat_'+self.data_name)
        # self.A_paths = pd.read_csv(self.source_list).values.tolist()
        # self.B_paths = pd.read_csv(self.target_list).values.tolist()

        self.A_paths = np.random.permutation(pd.read_csv(self.source_list).values.tolist())
        self.B_paths = np.random.permutation(pd.read_csv(self.target_list).values.tolist())

        self.A_size = len(self.A_paths) 
        self.B_size = len(self.B_paths) 

        if opt.preprocess != 'none':
            self.transform = iaa.Affine(scale=(0.9, 1.1), rotate=(-10, 10))
        else:
            self.transform = None
        print('len mr path: {}, len ct path {}'.format(len(self.A_paths), len(self.B_paths)))
    
    def __len__(self):
        return max(self.A_size,self.B_size)

    def __getitem__(self, idx):

        B_path = self.B_paths[idx][0]
        A_path = self.A_paths[idx][0]

        # idx = idx % self.length
        # img_file = self.img_list[idx]
        # img_path = img_file[0]
        # label_path = img_file[1]
        # import pdb;pdb.set_trace()
        # volume_id_A = re.findall(f'mr_([0-9]+)_.+',A_path)[0]
        # mean_A, var_A = self.stat_dict[self.data[0]][volume_id_A]

        # volume_id_B = re.findall(f'ct_([0-9]+)_.+',B_path)[0]
        # mean_B, var_B = self.stat_dict[self.data[1]][volume_id_B]
        
        A = np.load(A_path)
        A = A.squeeze() if len(A.shape)!=2 else A
        B = np.load(B_path)
        B = B.squeeze() if len(B.shape)!=2 else B
        
        # A = (A-mean_A)/var_A
        # B = (B-mean_B)/var_B

        # if self.transform:
        #     A = self.transform(images=A)
        #     B = self.transform(images=B)

        return {'A': torch.tensor(A[np.newaxis, :]).float(), 'B': torch.tensor(B[np.newaxis, :]).float(), 'A_paths': A_path, 'B_paths': B_path}
# if __name__ =="__main__":
#     # data_list = '/home1/ziyuan/UDA/data/chaos_morph/split_csv/ct_train.csv'
#     # train_set = chaos_morph(data_list, phase = 'train',data ='fake_ct', transform=True)
#     # data_list = '/home1/ziyuan/UDA/data/chaos_morph/split_csv/ct_test.csv'
#     # train_set = chaos_morph(data_list, phase = 'test',data ='ct', transform=False)
#     data_list = '/home/ziyuan/UDA/Meta_istn/split_csv/source.csv'
#     train_set = dataset_meta_istn(data_list,dataset = 'chaos', phase = 'test',data ='mr', transform=False)
#     for i in range(20):
#         sample = train_set[i]
#         print(sample['image'].shape,sample['label'].shape, sample['vol_id'])
