"""Dataset class template

This module provides a template for users to implement custom datasets.
You can specify '--dataset_mode template' to use this dataset.
The class name should be consistent with both the filename and its dataset_mode option.
The filename should be <dataset_mode>_dataset.py
The class name should be <Dataset_mode>Dataset.py
You need to implement the following functions:
    -- <modify_commandline_options>:　Add dataset-specific options and rewrite default values for existing options.
    -- <__init__>: Initialize this dataset class.
    -- <__getitem__>: Return a data point and its metadata information.
    -- <__len__>: Return the number of images.
"""
import os
# import sys
# sys.path.append('/home/ziyuan/UDA/code/CycleGAN')
from options.train_options import TrainOptions
# from base_dataset import BaseDataset, get_transform
# from image_folder import make_dataset
from data.base_dataset import BaseDataset, get_transform
from data.image_folder import make_dataset
# from PIL import Image
import SimpleITK as sitk
import cv2
import numpy as np
import random
import torch
import imgaug.augmenters as iaa


class CrossmodaDataset(BaseDataset):
    """A template dataset class for you to implement custom datasets."""
    @staticmethod
    def modify_commandline_options(parser, is_train):
        """Add new dataset-specific options, and rewrite default values for existing options.

        Parameters:
            parser          -- original option parser
            is_train (bool) -- whether training phase or test phase. You can use this flag to add training-specific or test-specific options.

        Returns:
            the modified parser.
        """
        parser.add_argument('--new_dataset_option', type=float, default=1.0, help='new dataset option')
        parser.set_defaults(max_dataset_size=10, new_dataset_option=2.0)  # specify dataset-specific default values
        return parser

    def __init__(self, opt):
        """Initialize this dataset class.

        Parameters:
            opt (Option class) -- stores all the experiment flags; needs to be a subclass of BaseOptions

        A few things can be done here.
        - save the options (have been done in BaseDataset)
        - get image paths and meta information of the dataset.
        - define the image transformation.
        """
        # save the option and dataset root
        BaseDataset.__init__(self, opt)
        # get the image paths of your dataset;
        self.opt = opt
        self.A_dir = '/diskd/ziyuan/fangcheng/crossmoda/process/npy/source_training'
        # self.B_dir = '/diskd/ziyuan/fangcheng/crossmoda/process/npy/target_training'
        self.B_dir = '/diskd/ziyuan/fangcheng/crossmoda/process/npy/target_val'
        self.phase = opt.phase
        if opt.phase == 'test':
            with open('/diskd/ziyuan/fangcheng/crossmoda/process/npy/source_training_with_label.txt') as f:
                self.A_paths = f.readlines()
            self.A_paths = [fn.strip() for fn in self.A_paths]
        else:
            self.A_paths = [os.path.join(self.A_dir, fn) for fn in os.listdir(self.A_dir) if 'label' not in fn]
        self.B_paths = [os.path.join(self.B_dir, fn) for fn in os.listdir(self.B_dir)]
        self.A_size = len(self.A_paths)  # get the size of dataset A
        self.B_size = len(self.B_paths)  # get the size of dataset B

        print('len T1 path: {}, len T2 path {}'.format(len(self.A_paths), len(self.B_paths)))

        # define the default transform function. You can use <base_dataset.get_transform>; You can also define your custom transform function

    def __getitem__(self, index):
        """Return a data point and its metadata information.

        Parameters:
            index -- a random integer for data indexing

        Returns:
            a dictionary of data with their names. It usually contains the data itself and its metadata information.

        Step 1: get a random image path: e.g., path = self.image_paths[index]
        Step 2: load your data from the disk: e.g., image = Image.open(path).convert('RGB').
        Step 3: convert your data to a PyTorch tensor. You can use helpder functions such as self.transform. e.g., data = self.transform(image)
        Step 4: return a data point as a dictionary.
        """
        """
        ce.shape = (120, 512, 511) t2.shape = (80, 448, 448) or (40, 348, 348)
        """
        A_path = self.A_paths[index % self.A_size]
        A = np.load(os.path.join(self.A_dir, A_path))
        # print(A.max())
        
        if self.phase == 'test':
            index_B = index%self.B_size
        else:
            index_B = random.randint(0, self.B_size - 1)
        B_path = self.B_paths[index_B]
        B= np.load(os.path.join(self.B_dir, B_path))

        resize_shape = (256, 256)
        transform = iaa.Resize(resize_shape)
        # A = cv2.resize(A, resize_shape, interpolation=cv2.INTER_NEAREST)
        # B = cv2.resize(B, resize_shape, interpolation=cv2.INTER_NEAREST)
        A = transform(images = A)
        B = transform(images = B)

        # print('A.sum', data_A.sum(), 'B.sum', data_B.sum())
        # print('A_img_ind',A_img_ind,'B_img_ind',B_img_ind, 'A_slice_ind',A_slice_ind, "B_slice_ind", B_slice_ind)
        # return  {'A': A.float(), 'B': B.float(), 'A_paths': A_path, 'B_paths': B_path}
        return  {'A': torch.tensor(A[np.newaxis, :].astype(np.float32)).float(), 'B': torch.tensor(B[np.newaxis, :].astype(np.float32)).float(), 'A_paths': A_path, 'B_paths': B_path}

    def __len__(self):
        """Return the total number of images."""
        return max(self.A_size,self.B_size) if self.opt.phase != 'test' else self.A_size


    def pad_array(self, array, target_shape):
        target_shape = np.array(target_shape)
        ar_shape = np.array(array.shape)
        pad_shape = target_shape - ar_shape
        pad_before = pad_shape // 2
        pad_after = pad_shape - pad_before
        pad_width = tuple(zip(pad_before, pad_after))
        padded_ar = np.pad(array, pad_width, mode='constant', constant_values=0)

        return padded_ar


if __name__ == '__main__':
    opt = TrainOptions().parse()
    Dataset = CrossmodaDataset(opt)
    data9 = Dataset[9]
    print(data9['A'].shape, data9['B'].shape)
    print(data9['A'].max(), data9['A'].mean())
    # print(Dataset.A_paths)
