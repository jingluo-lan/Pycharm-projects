"""Dataset class template

This module provides a template for users to implement custom datasets.
You can specify '--dataset_mode template' to use this dataset.
The class name should be consistent with both the filename and its dataset_mode option.
The filename should be <dataset_mode>_dataset.py
The class name should be <Dataset_mode>Dataset.py
You need to implement the following functions:
    -- <modify_commandline_options>: Add dataset-specific options and rewrite default values for existing options.
    -- <__init__>: Initialize this dataset class.
    -- <__getitem__>: Return a data point and its metadata information.
    -- <__len__>: Return the number of images.
"""
import os
import sys
sys.path.append('/home/ziyuan/UDA/code/CycleGAN')
from data.base_dataset import BaseDataset, get_transform
from data.image_folder import make_dataset
from options.train_options import TrainOptions
from PIL import Image
import SimpleITK as sitk
import cv2
import numpy as np
import random
import torch
import torchvision.transforms as transforms
import imgaug.augmenters as iaa
import re


# stat_dict_ourdata = {
#  'ct':{'1001': (-0.412, 0.345), '1002': (0.048, 0.364), '1004': (0.062, 0.417), '1005': (0.104, 0.383),
#  '1006': (-0.065, 0.281), '1007': (0.168, 0.351), '1009': (-0.147, 0.308), '1010': (-0.172, 0.404),
#  '1011': (-0.088, 0.35), '1012': (0.096, 0.381),'1013': (0.026, 0.418), '1015': (-0.109, 0.463),
#  '1016': (-0.407, 0.354), '1017': (0.087, 0.464), '1018': (0.189, 0.374), '1020': (-0.406, 0.348),
#  '1008': (0.464,0.269), '1019': (0.313,0.227), '1014': (0.239,0.215), '1003': (0.254,0.192)},
#  'mr':{'1001': (-0.796, 0.174), '1002': (-0.613, 0.291), '1003': (-0.586, 0.513), '1004': (-0.773, 0.367),
#  '1005': (-0.732, 0.417), '1006': (-0.58, 0.488), '1008': (-0.696, 0.451), '1010': (-0.609, 0.48),
#  '1011': (-0.599, 0.5), '1012': (-0.726, 0.228), '1013': (-0.563, 0.341), '1014': (-0.625, 0.272),
#  '1015': (-0.497, 0.526), '1016': (-0.748, 0.373), '1017': (-0.775, 0.339), '1020': (-0.691, 0.421),
#  '1007': (0.205, 0.234), '1009': (0.206, 0.166), '1018': (0.173, 0.235), '1019': (0.146, 0.208)},
#  'cyc_ct':{'1001': (-0.317, 0.387), '1002': (0.05, 0.402), '1004': (0.084, 0.441), '1005': (0.104, 0.4),
#  '1006': (0.002, 0.353), '1007': (0.132, 0.382), '1009': (-0.079, 0.326), '1010': (-0.088, 0.428),
#  '1011': (-0.012, 0.382), '1012': (0.104, 0.397), '1013': (0.067, 0.433), '1015': (-0.032, 0.465),
#  '1016': (-0.328, 0.377), '1017': (0.105, 0.472), '1018': (0.183, 0.405), '1020': (-0.314, 0.388)},
#  'cyc_mr':{'1001': (-0.701, 0.147), '1002': (-0.588, 0.29), '1003': (-0.513, 0.475), '1004': (-0.69, 0.305),
#  '1005': (-0.667, 0.374), '1006': (-0.51, 0.458), '1008': (-0.627, 0.401), '1010': (-0.566, 0.452),
#  '1011': (-0.542, 0.462), '1012': (-0.695, 0.178), '1013': (-0.481, 0.375), '1014': (-0.54, 0.281),
#  '1015': (-0.448, 0.516), '1016': (-0.714, 0.326), '1017': (-0.734, 0.285), '1020': (-0.643, 0.376)},
#  'fake_ct':{'1001': (-0.451, 0.259), '1002': (-0.13, 0.346), '1003': (-0.204, 0.445), '1004': (-0.425, 0.402),
#  '1005': (-0.4, 0.394), '1006': (-0.182, 0.457), '1008': (-0.32, 0.455), '1010': (-0.249, 0.452),
#  '1011': (-0.294, 0.47), '1012': (-0.259, 0.293), '1013': (-0.152, 0.331), '1014': (-0.143, 0.331),
#  '1015': (-0.138, 0.478), '1016': (-0.429, 0.418), '1017': (-0.457, 0.367), '1020': (-0.348, 0.435),
#  '1007': (-0.027, 0.403), '1009': (-0.23, 0.801), '1018': (-0.137, 0.428), '1019': (-0.236, 0.409)},
#  'fake_mr':{'1001': (-0.706, 0.289), '1002': (-0.687, 0.43), '1004': (-0.654, 0.459), '1005': (-0.646, 0.425),
#  '1006': (-0.695, 0.298), '1007': (-0.615, 0.413), '1009': (-0.73, 0.273), '1010': (-0.742, 0.332),
#  '1011': (-0.724, 0.356), '1012': (-0.655, 0.414), '1013': (-0.684, 0.414), '1015': (-0.714, 0.375),
#  '1016': (-0.71, 0.284), '1017': (-0.629, 0.411), '1018': (-0.599, 0.438), '1020': (-0.712, 0.284),
#  '1003': (-0.766, 0.259), '1008': (-0.672, 0.389), '1014': (-0.767, 0.294), '1019': (-0.79, 0.258)}}

stat_dict_ourdata = {
'ct':{'1001': (-0.423, 0.345), '1002': (0.0269, 0.3778), '1003': (-0.4865, 0.3784), '1004': (0.0318, 0.4298),
'1005': (0.0873, 0.3998), '1006': (-0.0731, 0.2866), '1007': (0.1582, 0.3622), '1008': (-0.0721, 0.5385),
'1009': (-0.1541, 0.3165), '1010': (-0.1763, 0.405), '1011': (-0.0994, 0.362), '1012': (0.0785, 0.3989),
'1013': (0.0151, 0.4304), '1014': (-0.5174, 0.4243), '1015': (-0.1183, 0.4675), '1016': (-0.4154, 0.352),
'1017': (0.0768, 0.4715), '1018': (0.1767, 0.3836), '1019': (-0.3712, 0.4517), '1020': (-0.4183, 0.3482)},
'mr': {'1001': (-0.7982, 0.1731), '1002': (-0.6206, 0.2913), '1003': (-0.587, 0.5024), '1004': (-0.7688, 0.3604),
'1005': (-0.73, 0.407), '1006': (-0.5852, 0.4755), '1007': (-0.5854, 0.4634), '1008': (-0.6909, 0.4446),
'1009': (-0.5875, 0.3312), '1010': (-0.6091, 0.4704), '1011': (-0.5957, 0.4913), '1012': (-0.7323, 0.2259),
'1013': (-0.5666, 0.341), '1014': (-0.6283, 0.2723), '1015': (-0.4937, 0.5237), '1016': (-0.7465, 0.3653),
'1017': (-0.7739, 0.3327), '1018': (-0.6485, 0.465), '1019': (-0.7026, 0.4124), '1020': (-0.6897, 0.413)},
}
class MMWHSDataset(BaseDataset):
    """A template dataset class for you to implement custom datasets."""
    @staticmethod
    def modify_commandline_options(parser, is_train):
        """Add new dataset-specific options, and rewrite default values for existing options.

        Parameters:
            parser          -- original option parser
            is_train (bool) -- whether training phase or test phase. You can use this flag to add training-specific or test-specific options.

        Returns:
            the modified parser.
        """
        parser.add_argument('--new_dataset_option', type=float, default=1.0, help='new dataset option')
        parser.set_defaults(max_dataset_size=10, new_dataset_option=2.0)  # specify dataset-specific default values
        return parser

    def __init__(self, opt):
        """Initialize this dataset class.

        Parameters:
            opt (Option class) -- stores all the experiment flags; needs to be a subclass of BaseOptions

        A few things can be done here.
        - save the options (have been done in BaseDataset)
        - get image paths and meta information of the dataset.
        - define the image transformation.
        """
        # save the option and dataset root
        BaseDataset.__init__(self, opt)
        # get the image paths of your dataset;
        # data_root '/data1/ziyuan/fangcheng/MMWHS_v6'
        self.phase = opt.phase # TODO debug the new file directory

        # preprocessing
        self.new_to_old = opt.new_to_old # not used
        self.zscore = opt.zscore
        # self.A_dir = os.path.join(opt.dataroot, 'mr', 'mr_'+opt.phase) # mr
        # self.B_dir = os.path.join(opt.dataroot, 'ct', 'ct_'+opt.phase) # ct
        # self.A_dir = os.path.join(opt.dataroot, 'mr', 'mr_labeled/org_mr') # mr
        # self.B_dir = os.path.join(opt.dataroot, 'ct', 'ct_labeled/org_ct') # ct
        # self.A_dir = os.path.join(opt.dataroot, 'mr', 'mr_like_test/org_mr') # mr
        # self.B_dir = os.path.join(opt.dataroot, 'ct', 'ct_like_test/org_ct') # ct
        # for v6
        # self.A_dir = os.path.join(opt.dataroot, 'mr', 'mr_test') # mr
        # self.B_dir = os.path.join(opt.dataroot, 'ct', 'ct_test') # ct
        self.A_dir = os.path.join(opt.dataroot, 'mr', 'mr_train') # mr
        self.B_dir = os.path.join(opt.dataroot, 'ct', 'ct_train') # ct
        # if opt.train25:
        #     self.A_paths = [f for f in os.listdir(self.A_dir) if 'label' not in f and (('1001' in f) or ('1006' in f) or ('1008' in f) or ('1010' in f))]
        # else:
        self.A_paths = [f for f in os.listdir(self.A_dir) if 'label' not in f]
        self.B_paths = [f for f in os.listdir(self.B_dir) if 'label' not in f]

        self.A_size = len(self.A_paths)  # get the size of dataset A
        self.B_size = len(self.B_paths)  # get the size of dataset B
        self.direction = opt.direction

        self.transform = transforms.Compose([transforms.RandomRotation(15),
                                             transforms.Resize(280),
                                             transforms.RandomCrop(256),
                                             transforms.RandomAffine(degrees=10, translate=(0, 0.1), shear=(-45, 45),
                                                                    scale=(0.8, 1.2)),
                                             transforms.ToTensor(),])
        # if opt.preprocess != 'none':
        #     self.transform = iaa.Affine(scale=(0.9, 1.1), rotate=(-10, 10))
        # else:
        #     self.transform = None
        print('len mr path: {}, len ct path {}'.format(len(self.A_paths), len(self.B_paths)))

        # define the default transform function. You can use <base_dataset.get_transform>; You can also define your custom transform function

    def __getitem__(self, index):
        """Return a data point and its metadata information.

        Parameters:
            index -- a random integer for data indexing

        Returns:
            a dictionary of data with their names. It usually contains the data itself and its metadata information.

        Step 1: get a random image path: e.g., path = self.image_paths[index]
        Step 2: load your data from the disk: e.g., image = Image.open(path).convert('RGB').
        Step 3: convert your data to a PyTorch tensor. You can use helpder functions such as self.transform. e.g., data = self.transform(image)
        Step 4: return a data point as a dictionary.
        """
        """
        ce.shape = (120, 512, 511) t2.shape = (80, 448, 448) or (40, 348, 348)
        """

        # uncomment the following to make direction effective
        # temporarily change to generate image
        if self.direction == 'AtoB':
            A_path = self.A_paths[index % self.A_size]
            index_B = random.randint(0, self.B_size - 1)
            B_path = self.B_paths[index_B]
            # B_path = self.B_paths[index % self.B_size]
            # index_A = random.randint(0, self.A_size - 1)
            # A_path = self.A_paths[index_A]

        else:
            B_path = self.B_paths[index % self.B_size]
            index_A = random.randint(0, self.A_size - 1)
            A_path = self.A_paths[index_A]

        A = np.load(os.path.join(self.A_dir, A_path))
        B= np.load(os.path.join(self.B_dir, B_path))
        # print(A_path)
        # print(B_path)
        # if self.phase != 'test':
        #     A = A[:,:,0]
        #     B = B[:,:,0]

        # if self.new_to_old:
        #     A = (A + 1.0) / 2
        #     B = (B + 1.0) / 2

        if self.zscore:
            img_modal = re.findall('(.+?)_[0-9]+.+', A_path.split('/')[-1])[0]
            img_vol = re.findall('.+_([0-9]+)_[0-9]+.+', A_path.split('/')[-1])[0]
            mean, std = stat_dict_ourdata[img_modal][img_vol]
            A = (A-mean)/std
            # -> -1, 1
            # A = 2 * ((A - A.min()) / (A.max() - B.min())) - 1

            img_modal = re.findall('(.+?)_[0-9]+.+', B_path.split('/')[-1])[0]
            img_vol = re.findall('.+_([0-9]+)_[0-9]+.+', B_path.split('/')[-1])[0]
            mean, std = stat_dict_ourdata[img_modal][img_vol]
            B = (B-mean)/std
            # -> -1, 1
            # B = 2 * ((B - B.min()) / (B.max() - B.min())) - 1

        # no transform during test
        if self.transform and self.phase != 'test':
            A = self.transform(Image.fromarray(A))
            B = self.transform(Image.fromarray(B))
        else:
            A = torch.tensor(A[np.newaxis, :]).float()
            B = torch.tensor(B[np.newaxis, :]).float()

        # print('pathA: %s, pathB: %s'%(A_path,B_path))

        return {'A': A, 'B': B, 'A_paths': A_path, 'B_paths': B_path}

        # return {'A': torch.tensor(A[np.newaxis, :]).float(), 'B': torch.tensor(B[np.newaxis, :]).float(), 'A_paths': A_path, 'B_paths': B_path}

    def __len__(self):
        """Return the total number of images."""
        return max(self.A_size,self.B_size)
        # return self.A_size



if __name__ == '__main__':
    opt = TrainOptions().parse()
    Dataset = MMWHSDataset(opt)

    data9 = Dataset[9]
    print(data9['A'].shape, data9['B'].shape)
    print(Dataset.A_size, Dataset.B_size)
    print(Dataset.B_paths[:10])
