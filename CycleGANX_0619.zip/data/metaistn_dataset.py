import re
import glob
import torch.utils.data as data
import numpy as np
import torch
import imgaug.augmenters as iaa
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
import pandas as pd
import sys
# sys.path.append('/home/ziyuan/UDA/Meta_istn_pre')
# from dataset.dataset_config import stat_dic_chaos,stat_dict_mmwhs,vol_stat_mmwhs,vol_stat_chaos
from data.base_dataset import BaseDataset
from torchvision import transforms
import random

totensor = transforms.ToTensor()


stat_dic_mmwhs = {
 'ct':{'1001': (-0.412, 0.345), '1002': (0.048, 0.364), '1004': (0.062, 0.417), '1005': (0.104, 0.383), 
 '1006': (-0.065, 0.281), '1007': (0.168, 0.351), '1009': (-0.147, 0.308), '1010': (-0.172, 0.404), 
 '1011': (-0.088, 0.35), '1012': (0.096, 0.381),'1013': (0.026, 0.418), '1015': (-0.109, 0.463),
 '1016': (-0.407, 0.354), '1017': (0.087, 0.464), '1018': (0.189, 0.374), '1020': (-0.406, 0.348),
 '1008': (0.464,0.269), '1019': (0.313,0.227), '1014': (0.239,0.215), '1003': (0.254,0.192)},
 'mr':{'1001': (-0.796, 0.174), '1002': (-0.613, 0.291), '1003': (-0.586, 0.513), '1004': (-0.773, 0.367),
 '1005': (-0.732, 0.417), '1006': (-0.58, 0.488), '1008': (-0.696, 0.451), '1010': (-0.609, 0.48),
 '1011': (-0.599, 0.5), '1012': (-0.726, 0.228), '1013': (-0.563, 0.341), '1014': (-0.625, 0.272),
 '1015': (-0.497, 0.526), '1016': (-0.748, 0.373), '1017': (-0.775, 0.339), '1020': (-0.691, 0.421),
 '1007': (0.205, 0.234), '1009': (0.206, 0.166), '1018': (0.173, 0.235), '1019': (0.146, 0.208)},                  
 'cyc_ct':{'1001': (-0.317, 0.387), '1002': (0.05, 0.402), '1004': (0.084, 0.441), '1005': (0.104, 0.4),
 '1006': (0.002, 0.353), '1007': (0.132, 0.382), '1009': (-0.079, 0.326), '1010': (-0.088, 0.428),
 '1011': (-0.012, 0.382), '1012': (0.104, 0.397), '1013': (0.067, 0.433), '1015': (-0.032, 0.465),
 '1016': (-0.328, 0.377), '1017': (0.105, 0.472), '1018': (0.183, 0.405), '1020': (-0.314, 0.388)},
 'cyc_mr':{'1001': (-0.701, 0.147), '1002': (-0.588, 0.29), '1003': (-0.513, 0.475), '1004': (-0.69, 0.305),
 '1005': (-0.667, 0.374), '1006': (-0.51, 0.458), '1008': (-0.627, 0.401), '1010': (-0.566, 0.452),
 '1011': (-0.542, 0.462), '1012': (-0.695, 0.178), '1013': (-0.481, 0.375), '1014': (-0.54, 0.281),
 '1015': (-0.448, 0.516), '1016': (-0.714, 0.326), '1017': (-0.734, 0.285), '1020': (-0.643, 0.376)},
 'fake_ct':{'1001': (-0.451, 0.259), '1002': (-0.13, 0.346), '1003': (-0.204, 0.445), '1004': (-0.425, 0.402),
 '1005': (-0.4, 0.394), '1006': (-0.182, 0.457), '1008': (-0.32, 0.455), '1010': (-0.249, 0.452),
 '1011': (-0.294, 0.47), '1012': (-0.259, 0.293), '1013': (-0.152, 0.331), '1014': (-0.143, 0.331),
 '1015': (-0.138, 0.478), '1016': (-0.429, 0.418), '1017': (-0.457, 0.367), '1020': (-0.348, 0.435),
 '1007': (-0.027, 0.403), '1009': (-0.23, 0.801), '1018': (-0.137, 0.428), '1019': (-0.236, 0.409)},
 'fake_mr':{'1001': (-0.706, 0.289), '1002': (-0.687, 0.43), '1004': (-0.654, 0.459), '1005': (-0.646, 0.425),
 '1006': (-0.695, 0.298), '1007': (-0.615, 0.413), '1009': (-0.73, 0.273), '1010': (-0.742, 0.332),
 '1011': (-0.724, 0.356), '1012': (-0.655, 0.414), '1013': (-0.684, 0.414), '1015': (-0.714, 0.375),
 '1016': (-0.71, 0.284), '1017': (-0.629, 0.411), '1018': (-0.599, 0.438), '1020': (-0.712, 0.284),
 '1003': (-0.766, 0.259), '1008': (-0.672, 0.389), '1014': (-0.767, 0.294), '1019': (-0.79, 0.258)}}

class MetaISTNDataset(BaseDataset):
    @staticmethod
    def modify_commandline_options(parser, isTrain):
        parser.add_argument('--source_list', type=str, default='split_csv/source_all.csv', help='source list')
        parser.add_argument('--target_list', type=str, default='split_csv/target.csv', help='target list')
        parser.set_defaults(max_dataset_size=10, new_dataset_option=2.0)  # specify dataset-specific default values
        return parser
    def __init__(self, opt):
        
        BaseDataset.__init__(self, opt)
        self.data = ['mr', 'ct']
        self.source_list = opt.source_list
        self.target_list = opt.target_list
        # print('Now reading: '+datalist)
        # self.data_name = 'chaos'
        self.data_name = 'mmwhs'

        self.stat_dict = eval('stat_dic_'+self.data_name)
        # self.vol_stat = eval('vol_stat_'+self.data_name)


        self.A_paths = pd.read_csv(self.source_list).values.tolist()
        self.B_paths = pd.read_csv(self.target_list).values.tolist()

        self.A_size = len(self.A_paths) 
        self.B_size = len(self.B_paths) 

        if opt.preprocess != 'none':
            self.transform = iaa.Affine(scale=(0.9, 1.1), rotate=(-10, 10))
        else:
            self.transform = None
        print('len mr path: {}, len ct path {}'.format(len(self.A_paths), len(self.B_paths)))
    
    def __len__(self):
        return max(self.A_size,self.B_size)

    def __getitem__(self, idx):

        B_path = self.B_paths[idx % self.B_size][0]
        index_A = random.randint(0, self.A_size - 1)
        A_path = self.A_paths[index_A][0]

        # idx = idx % self.length
        # img_file = self.img_list[idx]
        # img_path = img_file[0]
        # label_path = img_file[1]
        # import pdb;pdb.set_trace()
        volume_id_A = re.findall(f'mr_([0-9]+)_.+',A_path)[0]
        mean_A, var_A = self.stat_dict[self.data[0]][volume_id_A]

        volume_id_B = re.findall(f'ct_([0-9]+)_.+',B_path)[0]
        mean_B, var_B = self.stat_dict[self.data[1]][volume_id_B]
        
        A = np.load(A_path)
        A = A.squeeze() if len(A.shape)!=2 else A
        B = np.load(B_path)
        B = B.squeeze() if len(B.shape)!=2 else B
        
        # A = (A+1)/2.0
        # B = (B+1)/2.0
        A = (A-mean_A)/var_A
        B = (B-mean_B)/var_B

        if self.transform:
            A = self.transform(images=A)
            B = self.transform(images=B)

        return {'A': torch.tensor(A[np.newaxis, :]).float(), 'B': torch.tensor(B[np.newaxis, :]).float(), 'A_paths': A_path, 'B_paths': B_path}
# if __name__ =="__main__":
#     # data_list = '/home1/ziyuan/UDA/data/chaos_morph/split_csv/ct_train.csv'
#     # train_set = chaos_morph(data_list, phase = 'train',data ='fake_ct', transform=True)
#     # data_list = '/home1/ziyuan/UDA/data/chaos_morph/split_csv/ct_test.csv'
#     # train_set = chaos_morph(data_list, phase = 'test',data ='ct', transform=False)
#     data_list = '/home/ziyuan/UDA/Meta_istn/split_csv/source.csv'
#     train_set = dataset_meta_istn(data_list,dataset = 'chaos', phase = 'test',data ='mr', transform=False)
#     for i in range(20):
#         sample = train_set[i]
#         print(sample['image'].shape,sample['label'].shape, sample['vol_id'])
