NAME=brats18_t2_flair_np
DATA=/data1/UDAX/brats18
GPU=0
MODEL=cycle_gan
SOURCE=${DATA}/t2/t2_labeled/t2_org_labeled.csv
TARGET=${DATA}/flair/flair_labeled/flair_org_labeled.csv
python train.py --dataroot $DATA --phase train --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 4 --n_epochs 100 --n_epochs_decay 100 --lr 0.0002\
 --source_list $SOURCE --target_list $TARGET

