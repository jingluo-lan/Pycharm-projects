python test.py --dataroot /home/user/lanzheng/CycleGAN/CycleGANX/datasets/mmwhs --phase test --name mmwhs_mr2ct --max_dataset_size 10000 --gpu_ids 0 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 --direction AtoB --preprocess none --epoch 50

#python test.py --dataroot /home/user/lanzheng/pycharm/CycleGAN/CycleGANX/datasets/mmwhs --phase test --name mmwhs_mr2ct --max_dataset_size 10000 --gpu_ids 1 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 --direction AtoB --preprocess none

# python test.py --dataroot /home/ziyuan/UDA/chaos --phase test --name chaos_ct2mr --max_dataset_size 10000 --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode chaos --batch_size 1 --num_test 100000 --direction BtoA --preprocess none

# python test.py --dataroot /home/ziyuan/UDA/chaos --phase train --name chaos_ct2mr --max_dataset_size 10000 --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode chaos --batch_size 1 --num_test 100000 --direction BtoA --preprocess none
