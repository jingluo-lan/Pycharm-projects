from models import create_model
from options.test_options import TestOptions

# 初始化测试选项（无命令行交互）
opt = TestOptions().parse()
opt.dataroot = '/home1/ziyuan/UDA/mmwhs_meta/'  # 指定新数据的路径
opt.checkpoints_dir = './checkpoints'  # 模型权重的路径
opt.name = 'mmwhs_epoch100_AtoB'  # 预训练模型的名字
opt.model = 'cycle_gan'
opt.num_threads = 0   # 测试时减少线程数
opt.batch_size = 1    # 测试模式下batch size设为1
opt.serial_batches = True  # 禁用数据打乱，保证顺序

model = create_model(opt)
model.setup(opt)
model.eval()
from data import create_dataset

dataset = create_dataset(opt)  # 使用测试选项创建新数据集
from torch.nn.functional import l1_loss

# 假设你已经定义了损失函数和必要的变量
cycle_loss_sum = 0.0
count = 0

for i, data in enumerate(dataset):
    model.set_input(data)  # 从数据集中获取数据
    model.test()           # 生成结果
    real_A = model.real_A
    fake_B = model.fake_B  # A到B
    rec_A = model.rec_A    # B到A，循环
    
    # 计算循环一致性损失
    cycle_loss = l1_loss(rec_A, real_A)
    cycle_loss_sum += cycle_loss.item()
    count += 1

average_cycle_loss = cycle_loss_sum / count
print(f"Average Cycle Consistency Loss: {average_cycle_loss}")
