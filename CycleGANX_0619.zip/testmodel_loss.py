import numpy as np
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

class NPYDataset(Dataset):
    def __init__(self, npy_files):
        self.npy_files = npy_files

    def __len__(self):
        return len(self.npy_files)

    def __getitem__(self, idx):
        npy_path = self.npy_files[idx]
        data = np.load(npy_path)
        data = Image.fromarray(data)  # 转换为PIL Image以使用transforms
        transform = transforms.Compose([
            transforms.Resize(256),  # 假设模型训练时的图像大小为256x256
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),  # 与训练时相同的归一化
        ])
        data = transform(data)
        return data

# 假设 results 文件夹下有测试数据
npy_files = ['./results/test_data1.npy', './results/test_data2.npy']  # 示例文件路径列表
dataset = NPYDataset(npy_files)
dataloader = DataLoader(dataset, batch_size=1, shuffle=False)
# 加载模型、设置为评估模式等步骤

# 循环遍历测试数据，计算损失
for data in dataloader:
    model.set_input(data)  # 为模型设置输入
    model.test()           # 生成转换图像
    # 计算损失的代码，如前面的示例所示
