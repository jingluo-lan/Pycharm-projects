"""General-purpose training script for image-to-image translation.

This script works for various models (with option '--model': e.g., pix2pix, cyclegan, colorization) and
different datasets (with option '--dataset_mode': e.g., aligned, unaligned, single, colorization).
You need to specify the dataset ('--dataroot'), experiment name ('--name'), and model ('--model').

It first creates model, dataset, and visualizer given the option.
It then does standard network training. During the training, it also visualize/save the images, print/save the loss plot, and save models.
The script supports continue/resume training. Use '--continue_train' to resume your previous training.

Example:
    Train a CycleGAN model:
        python train.py --dataroot ./datasets/maps --name maps_cyclegan --model cycle_gan
    Train a pix2pix model:
        python train.py --dataroot ./datasets/facades --name facades_pix2pix --model pix2pix --direction BtoA

See options/base_options.py and options/train_options.py for more training options.
See training and test tips at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/tips.md
See frequently asked questions at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/qa.md
"""
import time
from options.train_options import TrainOptions
from data import create_dataset
from models import create_model
from util.visualizer import Visualizer

from pytorch_gan_metrics import get_inception_score, calculate_frechet_inception_distance
from pytorch_fid import fid_score


import torch
from torch.nn.functional import interpolate
from torchvision import models

import torch
from torch.nn.functional import interpolate
from torchvision import models

def calculate_perceptual_path_length(generator, num_samples=10000, eps=1e-4):
    # 使用预训练的 VGG 模型来计算感知路径长度
    vgg = models.vgg16(pretrained=True).features
    vgg = vgg.cuda().eval()

    total_ppl = 0
    for _ in range(num_samples):
        z1 = torch.randn(1, 100).cuda()
        z2 = z1 + eps * torch.randn_like(z1).cuda()

        img1 = generator(z1)
        img2 = generator(z2)

        img1 = interpolate(img1, size=(224, 224), mode='bilinear', align_corners=False)
        img2 = interpolate(img2, size=(224, 224), mode='bilinear', align_corners=False)

        feat1 = vgg(img1).detach()
        feat2 = vgg(img2).detach()

        delta_feat = (feat1 - feat2).pow(2).mean().sqrt()
        total_ppl += delta_feat.item()

    return total_ppl / num_samples

if __name__ == '__main__':
    opt = TrainOptions().parse()   # get training options
    dataset = create_dataset(opt)  # create a dataset given opt.dataset_mode and other options
    dataset_size = len(dataset)    # get the number of images in the dataset.
    print('The number of training images = %d' % dataset_size)

    model = create_model(opt)      # create a model given opt.model and other options
    model.setup(opt)               # regular setup: load and print networks; create schedulers
    # print_log('    Total params: %.2fM' % (sum(p.numel() for p in model.parameters()) / 1000000.0))
    visualizer = Visualizer(opt)   # create a visualizer that display/save images and plots
    total_iters = 0                # the total number of training iterations

    for epoch in range(opt.epoch_count, opt.n_epochs + opt.n_epochs_decay + 1):    # outer loop for different epochs; we save the model by <epoch_count>, <epoch_count>+<save_latest_freq>
        epoch_start_time = time.time()  # timer for entire epoch
        iter_data_time = time.time()    # timer for data loading per iteration
        epoch_iter = 0                  # the number of training iterations in current epoch, reset to 0 every epoch
        visualizer.reset()              # reset the visualizer: make sure it saves the results to HTML at least once every epoch
        model.update_learning_rate()    # update learning rates in the beginning of every epoch.

#1
        all_generated_images = []  # 用于保存生成的图像以计算FID和IS
        all_real_images = []  # 用于保存真实图像以计算FID

        for i, data in enumerate(dataset):  # inner loop within one epoch
            iter_start_time = time.time()  # timer for computation per iteration
            if total_iters % opt.print_freq == 0:
                t_data = iter_start_time - iter_data_time

            total_iters += opt.batch_size
            epoch_iter += opt.batch_size
            # import pdb; pdb.set_trace()
            model.set_input(data)         # unpack data from dataset and apply preprocessing
            model.optimize_parameters()   # calculate loss functions, get gradients, update network weights

#2          # 保存生成和真实图像
            all_generated_images.append(model.fake_B.cpu())
            all_real_images.append(model.real_B.cpu())

            if total_iters % opt.display_freq == 0:   # display images on visdom and save images to a HTML file
                save_result = total_iters % opt.update_html_freq == 0
                model.compute_visuals()
                visualizer.display_current_results(model.get_current_visuals(), epoch, save_result)

            if total_iters % opt.print_freq == 0:    # print training losses and save logging information to the disk
                losses = model.get_current_losses()
                t_comp = (time.time() - iter_start_time) / opt.batch_size
                visualizer.print_current_losses(epoch, epoch_iter, losses, t_comp, t_data)
                if opt.display_id > 0:
                    visualizer.plot_current_losses(epoch, float(epoch_iter) / dataset_size, losses)

            if total_iters % opt.save_latest_freq == 0:   # cache our latest model every <save_latest_freq> iterations
                print('saving the latest model (epoch %d, total_iters %d)' % (epoch, total_iters))
                save_suffix = 'iter_%d' % total_iters if opt.save_by_iter else 'latest'
                model.save_networks(save_suffix)

            iter_data_time = time.time()

#3          # 将生成和真实图像转为numpy数组并转换为所需格式
            all_generated_images = torch.cat(all_generated_images, dim=0)
            all_real_images = torch.cat(all_real_images, dim=0)

            # 转换图像为numpy数组，并适配为输入IS、FID的格式
            transform = transforms.Compose([
                transforms.Resize((299, 299)),  # Inception网络需要299x299的输入
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # Inception网络的均值和标准差
            ])

            all_generated_images = [transform(img).numpy() for img in all_generated_images]
            all_real_images = [transform(img).numpy() for img in all_real_images]

            all_generated_images = np.stack(all_generated_images)
            all_real_images = np.stack(all_real_images)

            # 计算 Inception Score
            is_mean, is_std = get_inception_score(all_generated_images)
            print(f"Inception Score: {is_mean} ± {is_std}")

            # 计算 Fréchet Inception Distance
            fid = fid_score.calculate_fid_given_images(all_generated_images, all_real_images, batch_size=opt.batch_size)
            print(f"Fréchet Inception Distance: {fid}")

            # 计算 Perceptual Path Length (示例代码，需要根据具体实现调整)
            ppl = calculate_perceptual_path_length(model.netG_A)
            print(f"Perceptual Path Length: {ppl}")

        if epoch % opt.save_epoch_freq == 0:              # cache our model every <save_epoch_freq> epochs
            print('saving the model at the end of epoch %d, iters %d' % (epoch, total_iters))
            model.save_networks('latest')
            model.save_networks(epoch)

        print('End of epoch %d / %d \t Time Taken: %d sec' % (epoch, opt.n_epochs + opt.n_epochs_decay, time.time() - epoch_start_time))
