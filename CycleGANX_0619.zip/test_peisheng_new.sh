# python test.py --dataroot /home1/ziyuan/UDA/mmwhs_meta --phase test --name mmwhs_np --max_dataset_size 10000 --gpu_ids 2 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 --direction BtoA --preprocess none
# python test.py --dataroot /home1/ziyuan/UDA/mmwhs_meta --phase test --name mmwhs_np_BtoA --max_dataset_size 10000 --gpu_ids 2 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 --direction BtoA --preprocess none
# python test.py --dataroot /home1/ziyuan/UDA/mmwhs_meta --phase test --name mmwhs_np_BtoA_lr_0001 --max_dataset_size 10000 --gpu_ids 1 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 --direction BtoA --preprocess none

# python test.py --dataroot /home/ziyuan/UDA/chaos --phase test --name chaos_ct2mr --max_dataset_size 10000 --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode chaos --batch_size 1 --num_test 100000 --direction BtoA --preprocess none

# python test.py --dataroot /home/ziyuan/UDA/chaos --phase train --name chaos_ct2mr --max_dataset_size 10000 --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode chaos --batch_size 1 --num_test 100000 --direction BtoA --preprocess none

# mmwhs_np : Mr2CT

# use new data ...
# max dataset size should be ok
# python test.py --dataroot /home1/ziyuan/UDA/data/data_leuda_sifa_new --phase test --name mr_ct --max_dataset_size 20000 \
#     --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 \
#     --direction AtoB --preprocess none --epoch 50

# python test.py --dataroot /home1/interns/minqi/SIFA/mmwhs_MQ --phase test --name backup50_mr_ct --max_dataset_size 20000 \
#     --gpu_ids 3 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 \
#     --direction AtoB --preprocess none --epoch 50

python test.py --dataroot /home1/interns/minqi/SIFA/mmwhs_PS_11_v6_exclude_no_lbl --phase test --name v6_train_zscore_mr_ct --max_dataset_size 20000 \
    --gpu_ids 0 --model cycle_gan --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 1 --num_test 100000 \
    --direction AtoB --preprocess none --epoch 70