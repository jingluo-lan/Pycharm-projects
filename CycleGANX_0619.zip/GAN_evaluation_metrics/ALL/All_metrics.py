# import os
# import numpy as np
# import torch
# from pytorch_fid import fid_score
# from pytorch_gan_metrics import get_inception_score
# from torchvision.utils import save_image
# from torchvision import transforms
# from torch.utils.data import DataLoader, Dataset
# import logging
# from scipy.stats import wasserstein_distance
# from PIL import Image

# def setup_logger(log_dir, log_filename):
#     """Setup a logger to save logs to a specified directory and file."""
#     os.makedirs(log_dir, exist_ok=True)
#     log_path = os.path.join(log_dir, log_filename)
    
#     # Create a custom logger
#     logger = logging.getLogger('GANMetricsLogger')
#     logger.setLevel(logging.INFO)

#     # Create handlers
#     file_handler = logging.FileHandler(log_path)
#     stream_handler = logging.StreamHandler()

#     # Set level for handlers
#     file_handler.setLevel(logging.INFO)
#     stream_handler.setLevel(logging.INFO)

#     # Create formatters and add them to handlers
#     formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
#     file_handler.setFormatter(formatter)
#     stream_handler.setFormatter(formatter)

#     # Add handlers to the logger
#     logger.addHandler(file_handler)
#     logger.addHandler(stream_handler)

#     return logger

# def load_npy_files_from_directory(directory, logger):
#     """Load and return all .npy files from a specified directory, and list their names."""
#     npy_files = sorted([os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.npy')])
#     file_names = sorted([f for f in os.listdir(directory) if f.endswith('.npy')])
#     arrays = [np.load(npy_file) for npy_file in npy_files]
#     for array, file_name in zip(arrays, file_names):
#         logger.info(f"Loaded {file_name} with shape {array.shape}, min value: {array.min()}, max value: {array.max()}")
#     return np.stack(arrays, axis=0), file_names

# def convert_to_three_channel(images, logger):
#     """Convert single-channel images to three-channel images and normalize to [0, 1]."""
#     logger.info(f"Original shape: {images.shape}")
#     if images.ndim == 3:
#         images = images[:, :, :, np.newaxis]
#     logger.info(f"After adding new axis: {images.shape}")
#     images = np.repeat(images, 3, axis=-1)
#     logger.info(f"After repeating channels: {images.shape}")
#     images = images.transpose((0, 3, 1, 2))  # Transpose to (N, C, H, W)
#     logger.info(f"After transposing: {images.shape}")
#     return torch.tensor(images, dtype=torch.float32)

# def save_images_from_tensor(tensor, directory, file_names, logger):
#     """Save tensor images to a specified directory using provided file names."""
#     os.makedirs(directory, exist_ok=True)
#     for img, file_name in zip(tensor, file_names):
#         save_image(img, os.path.join(directory, f'{file_name}.png'))
#         logger.info(f"Saved {file_name}.png, min value: {img.min().item()}, max value: {img.max().item()}")

# class ImageDataset(Dataset):
#     def __init__(self, image_dir, transform=None):
#         self.image_dir = image_dir
#         self.image_files = sorted([os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.endswith('.png')])
#         self.transform = transform

#     def __len__(self):
#         return len(self.image_files)

#     def __getitem__(self, idx):
#         img_path = self.image_files[idx]
#         image = Image.open(img_path).convert('RGB')
#         if self.transform:
#             image = self.transform(image)
#         return image

# def compute_swd(real_loader, fake_loader, device):
#     real_images = []
#     fake_images = []
    
#     for real_batch, fake_batch in zip(real_loader, fake_loader):
#         real_images.append(real_batch.to(device))
#         fake_images.append(fake_batch.to(device))
    
#     real_images = torch.cat(real_images).cpu().numpy().reshape(len(real_images), -1)
#     fake_images = torch.cat(fake_images).cpu().numpy().reshape(len(fake_images), -1)
    
#     swd_value = wasserstein_distance(real_images.flatten(), fake_images.flatten())
#     return swd_value

# # 设置日志目录和文件名
# log_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/logs'
# log_filename = 'process1.log'
# logger = setup_logger(log_dir, log_filename)

# # 设置图像目录路径
# real_images_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/datasets/mmwhs/mr2ct/testB'
# generated_images_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/results/mmwhs_ct2mr/fake_mmwhs_ct2mr'

# # 加载并处理 .npy 文件
# real_images, real_image_files = load_npy_files_from_directory(real_images_dir, logger)
# generated_images, generated_image_files = load_npy_files_from_directory(generated_images_dir, logger)

# # 输出加载的文件名
# logger.info(f"Loaded real image files: {real_image_files}")
# logger.info(f"Loaded generated image files: {generated_image_files}")

# # 确认图像的实际形状
# logger.info(f"Shape of real images: {real_images.shape}")
# logger.info(f"Shape of generated images: {generated_images.shape}")

# # 转换为三通道图像并转为 PyTorch 张量
# real_images_tensor = convert_to_three_channel(real_images, logger)
# generated_images_tensor = convert_to_three_channel(generated_images, logger)

# # 临时保存张量为图像文件
# temp_real_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/temp_real_images'
# temp_generated_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/temp_generated_images'

# save_images_from_tensor(real_images_tensor, temp_real_image_dir, real_image_files, logger)
# save_images_from_tensor(generated_images_tensor, temp_generated_image_dir, generated_image_files, logger)

# # 计算 FID 分数
# fid_value = fid_score.calculate_fid_given_paths([temp_real_image_dir, temp_generated_image_dir],
#                                                 batch_size=50,
#                                                 device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
#                                                 dims=2048)
# logger.info(f'FID score: {fid_value}')

# # 计算 Inception Score (IS)
# transform = transforms.Compose([
#     transforms.Resize(299),
#     transforms.CenterCrop(299),
#     transforms.ToTensor(),
#     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
# ])

# generated_dataset = ImageDataset(temp_generated_image_dir, transform=transform)
# generated_loader = DataLoader(generated_dataset, batch_size=50, shuffle=False)

# generated_images_list = []
# for batch in generated_loader:
#     generated_images_list.append(batch)

# generated_images_tensor = torch.cat(generated_images_list, dim=0)
# is_mean, is_std = get_inception_score(generated_images_tensor, batch_size=50, splits=10)
# logger.info(f'Inception Score: Mean = {is_mean}, Std = {is_std}')

# # 计算 Sliced Wasserstein Distance (SWD)
# real_dataset = ImageDataset(temp_real_image_dir, transform=transform)
# fake_dataset = ImageDataset(temp_generated_image_dir, transform=transform)

# real_loader = DataLoader(real_dataset, batch_size=50, shuffle=False)
# fake_loader = DataLoader(fake_dataset, batch_size=50, shuffle=False)

# swd_value = compute_swd(real_loader, fake_loader, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
# logger.info(f'SWD: {swd_value}')

# # # 计算 Kernel Inception Distance (KID)
# # kid_mean, kid_std = calculate_kid_given_paths([temp_real_image_dir, temp_generated_image_dir],
# #                                               batch_size=50,
# #                                               device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
# # logger.info(f'KID: Mean = {kid_mean}, Std = {kid_std}')

import os
import numpy as np
import torch
from pytorch_fid import fid_score
from pytorch_gan_metrics import get_inception_score
from torchvision.utils import save_image
from torchvision import transforms
from torch.utils.data import DataLoader, Dataset
import logging
from scipy.stats import wasserstein_distance
from PIL import Image

def setup_logger(log_dir, log_filename):
    """Setup a logger to save logs to a specified directory and file."""
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, log_filename)
    
    # Create a custom logger
    logger = logging.getLogger('GANMetricsLogger')
    logger.setLevel(logging.INFO)

    # Create handlers
    file_handler = logging.FileHandler(log_path)
    stream_handler = logging.StreamHandler()

    # Set level for handlers
    file_handler.setLevel(logging.INFO)
    stream_handler.setLevel(logging.INFO)

    # Create formatters and add them to handlers
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)

    # Add handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return logger

def load_npy_files_from_directory(directory, logger):
    """Load and return all .npy files from a specified directory, and list their names."""
    npy_files = sorted([os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.npy')])
    file_names = sorted([f for f in os.listdir(directory) if f.endswith('.npy')])
    arrays = [np.load(npy_file) for npy_file in npy_files]
    for array, file_name in zip(arrays, file_names):
        logger.info(f"Loaded {file_name} with shape {array.shape}, min value: {array.min()}, max value: {array.max()}")
    return np.stack(arrays, axis=0), file_names

def convert_to_three_channel(images, logger):
    """Convert single-channel images to three-channel images and normalize to [0, 1]."""
    logger.info(f"Original shape: {images.shape}")
    if images.ndim == 3:
        images = images[:, :, :, np.newaxis]
    logger.info(f"After adding new axis: {images.shape}")
    images = np.repeat(images, 3, axis=-1)
    logger.info(f"After repeating channels: {images.shape}")
    images = images.transpose((0, 3, 1, 2))  # Transpose to (N, C, H, W)
    logger.info(f"After transposing: {images.shape}")
    return torch.tensor(images, dtype=torch.float32)

def save_images_from_tensor(tensor, directory, file_names, logger):
    """Save tensor images to a specified directory using provided file names."""
    os.makedirs(directory, exist_ok=True)
    for img, file_name in zip(tensor, file_names):
        save_image(img, os.path.join(directory, f'{file_name}.png'))
        logger.info(f"Saved {file_name}.png, min value: {img.min().item()}, max value: {img.max().item()}")

class ImageDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.image_files = sorted([os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.endswith('.png')])
        self.transform = transform

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image

def compute_swd(real_loader, fake_loader, device):
    real_images = []
    fake_images = []

    for real_batch, fake_batch in zip(real_loader, fake_loader):
        real_images.append(real_batch.to(device).view(real_batch.size(0), -1))
        fake_images.append(fake_batch.to(device).view(fake_batch.size(0), -1))

    real_images = torch.cat(real_images, dim=0).cpu().numpy()
    fake_images = torch.cat(fake_images, dim=0).cpu().numpy()

    # Use Wasserstein distance on flattened images
    swd_value = wasserstein_distance(real_images.flatten(), fake_images.flatten())
    return swd_value

# 设置日志目录和文件名
log_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/logs'
log_filename = 'process1.log'
logger = setup_logger(log_dir, log_filename)

# 设置图像目录路径
real_images_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/datasets/mmwhs/mr2ct/testB'
generated_images_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/results/mmwhs_ct2mr/fake_mmwhs_ct2mr'

# 加载并处理 .npy 文件
real_images, real_image_files = load_npy_files_from_directory(real_images_dir, logger)
generated_images, generated_image_files = load_npy_files_from_directory(generated_images_dir, logger)

# 输出加载的文件名
logger.info(f"Loaded real image files: {real_image_files}")
logger.info(f"Loaded generated image files: {generated_image_files}")

# 确认图像的实际形状
logger.info(f"Shape of real images: {real_images.shape}")
logger.info(f"Shape of generated images: {generated_images.shape}")

# 转换为三通道图像并转为 PyTorch 张量
real_images_tensor = convert_to_three_channel(real_images, logger)
generated_images_tensor = convert_to_three_channel(generated_images, logger)

# 临时保存张量为图像文件
temp_real_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/temp_real_images'
temp_generated_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/temp_generated_images'

save_images_from_tensor(real_images_tensor, temp_real_image_dir, real_image_files, logger)
save_images_from_tensor(generated_images_tensor, temp_generated_image_dir, generated_image_files, logger)

# 计算 FID 分数
fid_value = fid_score.calculate_fid_given_paths([temp_real_image_dir, temp_generated_image_dir],
                                                batch_size=50,
                                                device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
                                                dims=2048)
logger.info(f'FID score: {fid_value}')

# 计算 Inception Score (IS)
transform = transforms.Compose([
    transforms.Resize(299),
    transforms.CenterCrop(299),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

generated_dataset = ImageDataset(temp_generated_image_dir, transform=transform)
generated_loader = DataLoader(generated_dataset, batch_size=50, shuffle=False)

generated_images_list = []
for batch in generated_loader:
    generated_images_list.append(batch)

generated_images_tensor = torch.cat(generated_images_list, dim=0)
is_mean, is_std = get_inception_score(generated_images_tensor, batch_size=50, splits=10) #均值 (is_mean) 和标准差 (is_std)
logger.info(f'Inception Score: Mean = {is_mean}, Std = {is_std}')

# 计算 Sliced Wasserstein Distance (SWD)
real_dataset = ImageDataset(temp_real_image_dir, transform=transform)
fake_dataset = ImageDataset(temp_generated_image_dir, transform=transform)

real_loader = DataLoader(real_dataset, batch_size=50, shuffle=False)
fake_loader = DataLoader(fake_dataset, batch_size=50, shuffle=False)

swd_value = compute_swd(real_loader, fake_loader, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
logger.info(f'SWD: {swd_value}')

# # 计算 Kernel Inception Distance (KID)
# kid_mean, kid_std = calculate_kid_given_paths([temp_real_image_dir, temp_generated_image_dir],
#                                               batch_size=50,
#                                               device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
# logger.info(f'KID: Mean = {kid_mean}, Std = {kid_std}')
