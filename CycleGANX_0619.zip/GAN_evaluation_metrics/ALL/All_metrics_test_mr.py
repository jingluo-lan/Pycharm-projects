
import os
import numpy as np
import torch
from pytorch_fid import fid_score
from pytorch_gan_metrics import get_inception_score
from torchvision.utils import save_image
from torchvision import transforms
from torch.utils.data import DataLoader, Dataset
import logging
from scipy.stats import wasserstein_distance
from PIL import Image
from skimage.metrics import structural_similarity as ssim
import lpips

def setup_logger(log_dir, log_filename):
    """Setup a logger to save logs to a specified directory and file."""
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, log_filename)
    
    # Create a custom logger
    logger = logging.getLogger('GANMetricsLogger')
    logger.setLevel(logging.INFO)

    # Create handlers
    file_handler = logging.FileHandler(log_path)
    stream_handler = logging.StreamHandler()

    # Set level for handlers
    file_handler.setLevel(logging.INFO)
    stream_handler.setLevel(logging.INFO)

    # Create formatters and add them to handlers
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)

    # Add handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return logger

def load_npy_files_from_directory(directory, logger):
    """Load and return all .npy files from a specified directory, and list their names."""
    npy_files = sorted([os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.npy')])
    file_names = sorted([f for f in os.listdir(directory) if f.endswith('.npy')])
    arrays = []
    for npy_file, file_name in zip(npy_files, file_names):
        try:
            array = np.load(npy_file)
            arrays.append(array)
            logger.info(f"Loaded {file_name} with shape {array.shape}, min value: {array.min()}, max value: {array.max()}")
        except Exception as e:
            logger.error(f"Error loading {file_name}: {e}")
    return np.stack(arrays, axis=0), file_names

def convert_to_three_channel(images, logger):
    """Convert single-channel images to three-channel images and normalize to [0, 1]."""
    logger.info(f"Original shape: {images.shape}")
    if images.ndim == 3:
        images = images[:, :, :, np.newaxis]
    logger.info(f"After adding new axis: {images.shape}")
    images = np.repeat(images, 3, axis=-1)
    logger.info(f"After repeating channels: {images.shape}")
    images = images.transpose((0, 3, 1, 2))  # Transpose to (N, C, H, W)
    logger.info(f"After transposing: {images.shape}")
    return torch.tensor(images, dtype=torch.float32)

def save_images_from_tensor(tensor, directory, file_names, logger):
    """Save tensor images to a specified directory using provided file names."""
    os.makedirs(directory, exist_ok=True)
    for img, file_name in zip(tensor, file_names):
        save_image(img, os.path.join(directory, f'{file_name}.png'))
        logger.info(f"Saved {file_name}.png, min value: {img.min().item()}, max value: {img.max().item()}")

class ImageDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.image_files = sorted([os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.endswith('.png')])
        self.transform = transform

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image

def compute_swd(real_loader, fake_loader, device):
    real_images = []
    fake_images = []

    for real_batch, fake_batch in zip(real_loader, fake_loader):
        real_images.append(real_batch.to(device).view(real_batch.size(0), -1))
        fake_images.append(fake_batch.to(device).view(fake_batch.size(0), -1))

    real_images = torch.cat(real_images, dim=0).cpu().numpy()
    fake_images = torch.cat(fake_images, dim=0).cpu().numpy()

    # Use Wasserstein distance on flattened images
    swd_value = wasserstein_distance(real_images.flatten(), fake_images.flatten())
    return swd_value

def polynomial_kernel(x, y, degree=3, gamma=None, coef0=1):
    if gamma is None:
        gamma = 1.0 / x.shape[1]
    return (gamma * np.dot(x, y.T) + coef0) ** degree

def mmd(x, y, kernel=polynomial_kernel):
    xx = kernel(x, x)
    yy = kernel(y, y)
    xy = kernel(x, y)
    return np.mean(xx) + np.mean(yy) - 2 * np.mean(xy)

def get_inception_features(images, model, device):
    features = []
    for img in images:
        img = img.unsqueeze(0).to(device)
        with torch.no_grad():
            feature = model(img)[0].cpu().numpy().flatten()
        features.append(feature)
    return np.array(features)

def compute_kid(generated_images, real_images, model, device, num_subsets=10, subset_size=100):
    kid_values = []
    for _ in range(num_subsets):
        idx_gen = np.random.choice(len(generated_images), subset_size, replace=False)
        idx_real = np.random.choice(len(real_images), subset_size, replace=False)
        gen_subset = [generated_images[i] for i in idx_gen]
        real_subset = [real_images[i] for i in idx_real]
        gen_features = get_inception_features(gen_subset, model, device)
        real_features = get_inception_features(real_subset, model, device)
        kid_values.append(mmd(gen_features, real_features))
    return np.mean(kid_values), np.std(kid_values)

def compute_ssim(real_images_dir, generated_images_dir):
    real_images = sorted([os.path.join(real_images_dir, f) for f in os.listdir(real_images_dir) if f.endswith('.png')])
    generated_images = sorted([os.path.join(generated_images_dir, f) for f in os.listdir(generated_images_dir) if f.endswith('.png')])

    ssim_values = []

    for real_img_path, gen_img_path in zip(real_images, generated_images):
        real_img = Image.open(real_img_path).convert('L')
        gen_img = Image.open(gen_img_path).convert('L')

        real_img_np = np.array(real_img)
        gen_img_np = np.array(gen_img)

        ssim_value = ssim(real_img_np, gen_img_np)
        ssim_values.append(ssim_value)

    return np.mean(ssim_values)

from pytorch_msssim import ms_ssim

def compute_ms_ssim(real_images_dir, generated_images_dir, device):
    real_images = sorted([os.path.join(real_images_dir, f) for f in os.listdir(real_images_dir) if f.endswith('.png')])
    generated_images = sorted([os.path.join(generated_images_dir, f) for f in os.listdir(generated_images_dir) if f.endswith('.png')])

    ms_ssim_values = []

    for real_img_path, gen_img_path in zip(real_images, generated_images):
        real_img = Image.open(real_img_path).convert('RGB')
        gen_img = Image.open(gen_img_path).convert('RGB')

        real_img_tensor = transforms.ToTensor()(real_img).unsqueeze(0).to(device)
        gen_img_tensor = transforms.ToTensor()(gen_img).unsqueeze(0).to(device)

        ms_ssim_value = ms_ssim(real_img_tensor, gen_img_tensor, data_range=1.0)
        ms_ssim_values.append(ms_ssim_value.item())

    return np.mean(ms_ssim_values)


def compute_lpips(real_images_dir, generated_images_dir, device):
    lpips_model = lpips.LPIPS(net='alex').to(device)

    real_images = sorted([os.path.join(real_images_dir, f) for f in os.listdir(real_images_dir) if f.endswith('.png')])
    generated_images = sorted([os.path.join(generated_images_dir, f) for f in os.listdir(generated_images_dir) if f.endswith('.png')])

    lpips_values = []

    for real_img_path, gen_img_path in zip(real_images, generated_images):
        real_img = Image.open(real_img_path).convert('RGB')
        gen_img = Image.open(gen_img_path).convert('RGB')

        real_img_tensor = transforms.ToTensor()(real_img).unsqueeze(0).to(device)
        gen_img_tensor = transforms.ToTensor()(gen_img).unsqueeze(0).to(device)

        lpips_value = lpips_model(real_img_tensor, gen_img_tensor)
        lpips_values.append(lpips_value.item())

    return np.mean(lpips_values)

import torch.nn.functional as F
from torchvision.models import inception_v3, Inception_V3_Weights

def lerp(a, b, t):
    return a + (b - a) * t
def compute_ppl(generator, latent_dim, device, epsilon=1e-4, num_samples=10000, batch_size=32):
    distances = []
    generator.eval()
    
    for _ in range(num_samples // batch_size):
        z = torch.randn(batch_size, latent_dim, device=device)
        z_interp = lerp(z, z + torch.randn_like(z) * epsilon, 0.5)
        
        with torch.no_grad():
            img1 = generator(z)
            img2 = generator(z_interp)
        
        img1 = F.interpolate(img1, size=(299, 299), mode='bilinear', align_corners=False)
        img2 = F.interpolate(img2, size=(299, 299), mode='bilinear', align_corners=False)
        
        inception_model = inception_v3(pretrained=True, transform_input=False).to(device)
        inception_model.eval()
        
        with torch.no_grad():
            features1 = inception_model(img1).detach().cpu().numpy()
            features2 = inception_model(img2).detach().cpu().numpy()
        
        distances.append(np.linalg.norm(features1 - features2, axis=1))
    
    distances = np.concatenate(distances, axis=0)
    ppl_value = np.mean(distances)
    return ppl_value


# 设置日志目录和文件名
log_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/fakemr+realmr/epochs/80/logs'
log_filename = 'process1.log'
logger = setup_logger(log_dir, log_filename)



# 临时保存张量为图像文件
temp_real_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/fakemr+realmr/epochs/80/temp_real_images' #realmr
temp_generated_image_dir = '/home/user/lanzheng/CycleGAN/CycleGANX/GAN_evaluation_metrics/ALL/fakemr+realmr/epochs/80/temp_generated_images' #fakemr


# 计算 Inception Score (IS)
transform = transforms.Compose([
    transforms.Resize(299),
    transforms.CenterCrop(299),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

generated_dataset = ImageDataset(temp_generated_image_dir, transform=transform)
generated_loader = DataLoader(generated_dataset, batch_size=32, shuffle=False)

generated_images_list = []
for batch in generated_loader:
    generated_images_list.append(batch)

generated_images_tensor = torch.cat(generated_images_list, dim=0)
is_mean, is_std = get_inception_score(generated_images_tensor, batch_size=32, splits=10)
#logger.info(f'Inception Score: Mean = {is_mean}, Std = {is_std}')

# 计算 FID 分数
fid_value = fid_score.calculate_fid_given_paths([temp_real_image_dir, temp_generated_image_dir],
                                                batch_size=32,
                                                device=torch.device('cuda'),
                                                dims=2048)
#logger.info(f'FID score: {fid_value}')

# 加载Inception v3模型
from torchvision.models import inception_v3, Inception_V3_Weights

weights = Inception_V3_Weights.IMAGENET1K_V1
inception_model = inception_v3(weights=weights)
inception_model.eval()
inception_model.to(torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

# 转换为Inception v3接受的输入尺寸并进行归一化
transform = transforms.Compose([
    transforms.Resize(299),
    transforms.CenterCrop(299),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

real_dataset = ImageDataset(temp_real_image_dir, transform=transform)
fake_dataset = ImageDataset(temp_generated_image_dir, transform=transform)

real_loader = DataLoader(real_dataset, batch_size=32, shuffle=False)
fake_loader = DataLoader(fake_dataset, batch_size=32, shuffle=False)

# 提取特征并计算KID
real_images = []
fake_images = []

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
for real_batch, fake_batch in zip(real_loader, fake_loader):
    real_images.extend(real_batch)
    fake_images.extend(fake_batch)

# 计算KID
mean_kid, std_kid = compute_kid(fake_images, real_images, inception_model, device)
#logger.info(f'KID: Mean = {mean_kid}, Std = {std_kid}')

# 计算 Sliced Wasserstein Distance (SWD)
real_loader = DataLoader(real_dataset, batch_size=32, shuffle=False)
fake_loader = DataLoader(fake_dataset, batch_size=32, shuffle=False)

swd_value = compute_swd(real_loader, fake_loader, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
#logger.info(f'SWD: {swd_value}')

# 计算 SSIM
ssim_value = compute_ssim(temp_real_image_dir, temp_generated_image_dir)
#logger.info(f'SSIM: {ssim_value}')

# 计算 MS-SSIM
ms_ssim_value = compute_ms_ssim(temp_real_image_dir, temp_generated_image_dir, device)
#logger.info(f'MS-SSIM: {ms_ssim_value}')

# 计算 LPIPS
lpips_value = compute_lpips(temp_real_image_dir, temp_generated_image_dir, device)
#logger.info(f'LPIPS: {lpips_value}')

# # 确保你已经加载了生成器模型 `generator` 并设置了潜在维度 `latent_dim` 和设备 `device`
# ppl_value = compute_ppl(generator, latent_dim, device)
# #logger.info(f'PPL: {ppl_value:.2f}')

#IS FID KID SWD评价指标
# print("IS:优秀模型>5,(范围:通常从1到无穷大)")
# print("FID:优秀模型<30,(范围:0到无穷大)")
# print("KID:优秀模型<0.05,(范围:从0到1(或更高)")
# print("SWD: 理想情况下,值应尽可能接近于0")
# print("SSIM: 优秀模型 > 0.8,(范围:0到1)")
# print("MS-SSIM: 优秀模型 > 0.8,(范围:0到1)")
# print("LPIPS: 优秀模型 < 0.2,(范围:0到1)")



logger.info(f'Inception Score: Mean = {is_mean:.2f}, Std = {is_std:.2f},[优秀模型>5,(范围:通常从1到无穷大)]')
logger.info(f'FID score: {fid_value:.2f},[优秀模型<30,(范围:0到无穷大)]')
logger.info(f'KID: Mean = {mean_kid:.2f}, Std = {std_kid:.2f},[优秀模型<0.05,(范围:从0到1(或更高)]')
logger.info(f'SWD: {swd_value:.2f},[理想情况下,值应尽可能接近于0]')
logger.info(f'SSIM: {ssim_value:.2f},[优秀模型 > 0.8,(范围:0到1)]')
logger.info(f'MS-SSIM: {ms_ssim_value:.2f},[优秀模型 > 0.8,(范围:0到1)]')
logger.info(f'LPIPS: {lpips_value:.2f},[优秀模型 < 0.2,(范围:0到1)]')
#logger.info(f'PPL: {ppl_value:.2f}, [优秀模型 < 20, 越小越好]')
