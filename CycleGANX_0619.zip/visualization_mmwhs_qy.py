import numpy as np
import matplotlib.pyplot as plt
import matplotlib
#matplotlib.use('TkAgg')  # 或者尝试使用其他后端，如'Qt5Agg'

# org mr fake ct cyc mr, old data, no preprocessing

vol_id = '1007_32'
# org_mr = np.load(f'/home1/ziyuan/UDA/data/data_leuda_sifa_new/mr/mr_like/org_mr/mr_{vol_id}.npy')
org_mr = np.load(f'/home1/ziyuan/UDA/mmwhs_meta/mr/mr_test/org_mr/mr_{vol_id}.npy')
#/home1/intern2024/CycleGANX/visualization_mmwhs_qy.py
#CycleGANX/visualization_mmwhs_qy.py
#fake_ct = np.load(f'/home1/ziyuan/UDA/code/CycleGANX/results/v6_test_zscore_mr_ct/fake_ct_mr/fake_ct_{vol_id}.npy')
fake_ct = np.load(f'./results/mmwhs_epoch100_AtoB/fake_epoch100_AtoB/fake_epoch100_{vol_id}.npy')
# plt.imshow(fake_ct, cmap='gray')
#cyc_mr = np.load(f'/home1/ziyuan/UDA/code/CycleGANX/results/v6_test_zscore_mr_ct/cyc_mr_ct/cyc_mr_{vol_id}.npy')
cyc_mr = np.load(f'./results/mmwhs_epoch100_AtoB/cyc_AtoB_epoch100/cyc_AtoB_{vol_id}.npy')
# plt.imshow(cyc_mr, cmap='gray')

fig, ax = plt.subplots(1,3, figsize=(20, 20))
ax[0].imshow(org_mr, cmap='gray')
ax[1].imshow(fake_ct, cmap='gray')
ax[2].imshow(cyc_mr, cmap='gray')

plt.subplot(1, 3, 1)
plt.imshow(org_mr, cmap='gray')

plt.subplot(1, 3, 2)
plt.imshow(fake_ct, cmap='gray')

plt.subplot(1, 3, 3)
plt.imshow(cyc_mr, cmap='gray')