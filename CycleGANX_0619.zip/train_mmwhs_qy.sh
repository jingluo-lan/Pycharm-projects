NAME=mmwhs_epoch200_AtoB_datammwhs
#DATA=/home1/ziyuan/UDA/brats18
DATA=/home1/ziyuan/UDA/data/mmwhs
GPU=1
MODEL=cycle_gan
# SOURCE=${DATA}/ct/ct_labeled/org_ct_labeled.csv
# TARGET=${DATA}/mr/mr_labeled/org_mr_labeled.csv
python train.py --dataroot $DATA --phase train --name $NAME --direction AtoB --max_dataset_size 100 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 4 --n_epochs 200 --n_epochs_decay 1 --lr 0.0002\
 #--source_list $SOURCE --target_list $TARGET