DATA=/home1/ziyuan/UDA/brats18
GPU=1
# NAME=brats18_t2_flair
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/flair/flair_labeled/flair_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/t1/t1_labeled/t1_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET


# NAME=brats18_t2_t1ce
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/t1ce/t1ce_labeled/t1ce_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_flair
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/flair/flair_test/flair_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/t1/t1_test/t1_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET


# NAME=brats18_t2_t1ce
# GPU=0
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18_wholeslice/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18_wholeslice/t1ce/t1ce_test/t1ce_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_flair
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18/flair/flair_test/flair_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18/t1/t1_test/t1_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET


# NAME=brats18_t2_t1ce
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brats18/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brats18/t1ce/t1ce_test/t1ce_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# ---------------------------------------brast18_newsplit_TEST------------------------------
# DATA=/home1/ziyuan/UDA/brast18_newsplit
# NAME=brats18_t2_t1
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/t1/t1_test/t1_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_flair
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/flair/flair_test/flair_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1ce
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_test/t2_org_test.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/t1ce/t1ce_test/t1ce_org_test.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# # ---------------------------------------brast18_newsplit_TRAIN------------------------------

# DATA=/home1/ziyuan/UDA/brast18_newsplit
# NAME=brats18_t2_t1
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/t1/t1_labeled/t1_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_flair
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/flair/flair_labeled/flair_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1ce
# GPU=1
# MODEL=cycle_gan
# SOURCE=/home1/ziyuan/UDA/brast18_newsplit/t2/t2_labeled/t2_org_labeled.csv
# TARGET=/home1/ziyuan/UDA/brast18_newsplit/t1ce/t1ce_labeled/t1ce_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

 # ---------------------------------------brasts18_TRAIN------------------------------

# DATA=/data1/UDAX/brats18_ws
# NAME=brats18_t2_t1
# GPU=0
# MODEL=cycle_gan
# SOURCE=${DATA}/t2/t2_labeled/t2_org_labeled.csv
# TARGET=${DATA}/t1/t1_labeled/t1_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_flair
# GPU=0
# MODEL=cycle_gan
# SOURCE=${DATA}/t2/t2_labeled/t2_org_labeled.csv
# TARGET=${DATA}/flair/flair_labeled/flair_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

# NAME=brats18_t2_t1ce
# GPU=0
# MODEL=cycle_gan
# SOURCE=${DATA}/t2/t2_labeled/t2_org_labeled.csv
# TARGET=${DATA}/t1ce/t1ce_labeled/t1ce_org_labeled.csv
# python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 50000 --gpu_ids $GPU\
#  --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
#  --source_list $SOURCE --target_list $TARGET

#  # ---------------------------------------brats18_TEST------------------------------
DATA=/data1/UDAX/brats18_ws
NAME=brats18_t2_t1
GPU=1
MODEL=cycle_gan
SOURCE=${DATA}/t2/t2_test/t2_org_test.csv
TARGET=${DATA}/t1/t1_test/t1_org_test.csv
python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
 --source_list $SOURCE --target_list $TARGET

NAME=brats18_t2_flair
GPU=1
MODEL=cycle_gan
SOURCE=${DATA}/t2/t2_test/t2_org_test.csv
TARGET=${DATA}/flair/flair_test/flair_org_test.csv
python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
 --source_list $SOURCE --target_list $TARGET

NAME=brats18_t2_t1ce
GPU=1
MODEL=cycle_gan
SOURCE=${DATA}/t2/t2_test/t2_org_test.csv
TARGET=${DATA}/t1ce/t1ce_test/t1ce_org_test.csv
python test.py --dataroot $DATA --phase test --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode brats --batch_size 1\
 --source_list $SOURCE --target_list $TARGET