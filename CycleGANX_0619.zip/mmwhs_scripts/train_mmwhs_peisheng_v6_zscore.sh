NAME=v6_zscore_mr_ct
# DATA=/home1/ziyuan/UDA/mmwhs_meta
DATA=/home1/interns/minqi/SIFA/mmwhs_PS_11_v6_include_no_lbl
GPU=2
MODEL=cycle_gan
python train_peisheng_mmwhs.py --dataroot $DATA --phase train --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 4 --n_epochs 100 --n_epochs_decay 100 --lr 0.0002 --zscore
#  --preprocess resize_and_crop

# use pytorch transform

NAME=v7_no_zscore_mr_ct
# DATA=/home1/ziyuan/UDA/mmwhs_meta
DATA=/home1/interns/minqi/SIFA/mmwhs_PS_11_v7_include_no_lbl
GPU=3
MODEL=cycle_gan
python train_peisheng_mmwhs.py --dataroot $DATA --phase train --name $NAME --direction AtoB --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 4 --n_epochs 100 --n_epochs_decay 100 --lr 0.0002
