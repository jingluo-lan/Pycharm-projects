NAME=mmwhs_np_BtoA
DATA=/home1/ziyuan/UDA/mmwhs_meta
GPU=2
MODEL=cycle_gan
# SOURCE=${DATA}/ct/ct_labeled/org_ct_labeled.csv
# TARGET=${DATA}/mr/mr_labeled/org_mr_labeled.csv
python train.py --dataroot $DATA --phase train --name $NAME --direction BtoA --max_dataset_size 10000 --gpu_ids $GPU\
 --model $MODEL --input_nc 1 --output_nc 1 --dataset_mode mmwhs --batch_size 4 --n_epochs 100 --n_epochs_decay 100 --lr 0.0002
#  --source_list $SOURCE --target_list $TARGET

